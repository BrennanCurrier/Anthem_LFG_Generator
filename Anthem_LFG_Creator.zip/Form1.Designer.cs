﻿namespace Anthem_LFG_Creator
{
    partial class LFG_Creator_App
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.Combo_UITheme = new MetroFramework.Controls.MetroComboBox();
            this.lblTheme = new System.Windows.Forms.Label();
            this.bindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.txtBox_JavPower = new MetroFramework.Controls.MetroTextBox();
            this.combo_JavelinType = new MetroFramework.Controls.MetroComboBox();
            this.lblJavPower = new System.Windows.Forms.Label();
            this.lblJav = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.txtBox_PostDescription = new MetroFramework.Controls.MetroTextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.combo_MissionDiff = new MetroFramework.Controls.MetroComboBox();
            this.combo_MissionType = new MetroFramework.Controls.MetroComboBox();
            this.lblMissionDifficulty = new System.Windows.Forms.Label();
            this.lblMissionType = new System.Windows.Forms.Label();
            this.rb_LFM = new MetroFramework.Controls.MetroRadioButton();
            this.rb_LFG = new MetroFramework.Controls.MetroRadioButton();
            this.combo_LFM_Slots = new MetroFramework.Controls.MetroComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.tb_PostPreview = new MetroFramework.Controls.MetroTextBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.bttn_Copy = new MetroFramework.Controls.MetroButton();
            this.bttn_NewPost = new MetroFramework.Controls.MetroButton();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.SuspendLayout();
            // 
            // Combo_UITheme
            // 
            this.Combo_UITheme.FormattingEnabled = true;
            this.Combo_UITheme.ItemHeight = 23;
            this.Combo_UITheme.Items.AddRange(new object[] {
            "Dark",
            "Light"});
            this.Combo_UITheme.Location = new System.Drawing.Point(127, 63);
            this.Combo_UITheme.Name = "Combo_UITheme";
            this.Combo_UITheme.Size = new System.Drawing.Size(79, 29);
            this.Combo_UITheme.TabIndex = 0;
            this.Combo_UITheme.SelectedIndexChanged += new System.EventHandler(this.Combo_UITheme_SelectedIndexChanged);
            // 
            // lblTheme
            // 
            this.lblTheme.AutoSize = true;
            this.lblTheme.BackColor = System.Drawing.Color.Transparent;
            this.lblTheme.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.lblTheme.ForeColor = System.Drawing.Color.Black;
            this.lblTheme.Location = new System.Drawing.Point(23, 68);
            this.lblTheme.Name = "lblTheme";
            this.lblTheme.Size = new System.Drawing.Size(98, 24);
            this.lblTheme.TabIndex = 1;
            this.lblTheme.Text = "UI Theme:";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.groupBox5);
            this.groupBox1.Controls.Add(this.groupBox4);
            this.groupBox1.Controls.Add(this.groupBox3);
            this.groupBox1.Controls.Add(this.rb_LFM);
            this.groupBox1.Controls.Add(this.rb_LFG);
            this.groupBox1.Controls.Add(this.combo_LFM_Slots);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.groupBox1.Location = new System.Drawing.Point(27, 98);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(278, 469);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Post Options:";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.txtBox_JavPower);
            this.groupBox5.Controls.Add(this.combo_JavelinType);
            this.groupBox5.Controls.Add(this.lblJavPower);
            this.groupBox5.Controls.Add(this.lblJav);
            this.groupBox5.Location = new System.Drawing.Point(6, 170);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(260, 107);
            this.groupBox5.TabIndex = 7;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Javelin Options:";
            // 
            // txtBox_JavPower
            // 
            this.txtBox_JavPower.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBox_JavPower.Location = new System.Drawing.Point(146, 61);
            this.txtBox_JavPower.Name = "txtBox_JavPower";
            this.txtBox_JavPower.Size = new System.Drawing.Size(102, 34);
            this.txtBox_JavPower.TabIndex = 3;
            this.txtBox_JavPower.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // combo_JavelinType
            // 
            this.combo_JavelinType.FormattingEnabled = true;
            this.combo_JavelinType.ItemHeight = 23;
            this.combo_JavelinType.Items.AddRange(new object[] {
            "Ranger",
            "Colossus",
            "Interceptor",
            "Storm"});
            this.combo_JavelinType.Location = new System.Drawing.Point(85, 26);
            this.combo_JavelinType.Name = "combo_JavelinType";
            this.combo_JavelinType.Size = new System.Drawing.Size(163, 29);
            this.combo_JavelinType.TabIndex = 2;
            // 
            // lblJavPower
            // 
            this.lblJavPower.AutoSize = true;
            this.lblJavPower.Location = new System.Drawing.Point(11, 62);
            this.lblJavPower.Name = "lblJavPower";
            this.lblJavPower.Size = new System.Drawing.Size(137, 24);
            this.lblJavPower.TabIndex = 1;
            this.lblJavPower.Text = "Javelin Power: ";
            // 
            // lblJav
            // 
            this.lblJav.AutoSize = true;
            this.lblJav.Location = new System.Drawing.Point(11, 29);
            this.lblJav.Name = "lblJav";
            this.lblJav.Size = new System.Drawing.Size(78, 24);
            this.lblJav.TabIndex = 0;
            this.lblJav.Text = "Javelin: ";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.txtBox_PostDescription);
            this.groupBox4.Location = new System.Drawing.Point(6, 292);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(260, 163);
            this.groupBox4.TabIndex = 6;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Post Description:";
            // 
            // txtBox_PostDescription
            // 
            this.txtBox_PostDescription.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBox_PostDescription.Location = new System.Drawing.Point(9, 28);
            this.txtBox_PostDescription.Multiline = true;
            this.txtBox_PostDescription.Name = "txtBox_PostDescription";
            this.txtBox_PostDescription.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtBox_PostDescription.Size = new System.Drawing.Size(245, 128);
            this.txtBox_PostDescription.TabIndex = 0;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.combo_MissionDiff);
            this.groupBox3.Controls.Add(this.combo_MissionType);
            this.groupBox3.Controls.Add(this.lblMissionDifficulty);
            this.groupBox3.Controls.Add(this.lblMissionType);
            this.groupBox3.Location = new System.Drawing.Point(6, 59);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(266, 105);
            this.groupBox3.TabIndex = 5;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Mission Options:";
            // 
            // combo_MissionDiff
            // 
            this.combo_MissionDiff.FormattingEnabled = true;
            this.combo_MissionDiff.ItemHeight = 23;
            this.combo_MissionDiff.Items.AddRange(new object[] {
            "Easy",
            "Normal",
            "Hard",
            "Grandmaster 1",
            "Grandmaster 2",
            "Grandmaster 3"});
            this.combo_MissionDiff.Location = new System.Drawing.Point(94, 66);
            this.combo_MissionDiff.Name = "combo_MissionDiff";
            this.combo_MissionDiff.Size = new System.Drawing.Size(166, 29);
            this.combo_MissionDiff.TabIndex = 3;
            // 
            // combo_MissionType
            // 
            this.combo_MissionType.FormattingEnabled = true;
            this.combo_MissionType.ItemHeight = 23;
            this.combo_MissionType.Items.AddRange(new object[] {
            "Stronghold",
            "Mission",
            "Contract",
            "Legendary Contract",
            "Free Roam"});
            this.combo_MissionType.Location = new System.Drawing.Point(70, 26);
            this.combo_MissionType.Name = "combo_MissionType";
            this.combo_MissionType.Size = new System.Drawing.Size(190, 29);
            this.combo_MissionType.TabIndex = 2;
            // 
            // lblMissionDifficulty
            // 
            this.lblMissionDifficulty.AutoSize = true;
            this.lblMissionDifficulty.Location = new System.Drawing.Point(7, 69);
            this.lblMissionDifficulty.Name = "lblMissionDifficulty";
            this.lblMissionDifficulty.Size = new System.Drawing.Size(87, 24);
            this.lblMissionDifficulty.TabIndex = 1;
            this.lblMissionDifficulty.Text = "Difficulty: ";
            // 
            // lblMissionType
            // 
            this.lblMissionType.AutoSize = true;
            this.lblMissionType.Location = new System.Drawing.Point(7, 29);
            this.lblMissionType.Name = "lblMissionType";
            this.lblMissionType.Size = new System.Drawing.Size(58, 24);
            this.lblMissionType.TabIndex = 0;
            this.lblMissionType.Text = "Type:";
            // 
            // rb_LFM
            // 
            this.rb_LFM.Location = new System.Drawing.Point(76, 29);
            this.rb_LFM.Name = "rb_LFM";
            this.rb_LFM.Size = new System.Drawing.Size(46, 25);
            this.rb_LFM.TabIndex = 4;
            this.rb_LFM.TabStop = true;
            this.rb_LFM.Text = "LFM";
            this.rb_LFM.Theme = "Dark";
            this.rb_LFM.UseVisualStyleBackColor = false;
            // 
            // rb_LFG
            // 
            this.rb_LFG.Location = new System.Drawing.Point(6, 29);
            this.rb_LFG.Name = "rb_LFG";
            this.rb_LFG.Size = new System.Drawing.Size(43, 25);
            this.rb_LFG.TabIndex = 4;
            this.rb_LFG.TabStop = true;
            this.rb_LFG.Text = "LFG";
            this.rb_LFG.Theme = "Dark";
            this.rb_LFG.UseVisualStyleBackColor = false;
            // 
            // combo_LFM_Slots
            // 
            this.combo_LFM_Slots.FormattingEnabled = true;
            this.combo_LFM_Slots.ItemHeight = 23;
            this.combo_LFM_Slots.Items.AddRange(new object[] {
            "1",
            "2",
            "3"});
            this.combo_LFM_Slots.Location = new System.Drawing.Point(209, 29);
            this.combo_LFM_Slots.Name = "combo_LFM_Slots";
            this.combo_LFM_Slots.Size = new System.Drawing.Size(45, 29);
            this.combo_LFM_Slots.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(148, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(55, 24);
            this.label1.TabIndex = 2;
            this.label1.Text = "Slots:";
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Tick += new System.EventHandler(this.Timer1_Tick);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.tb_PostPreview);
            this.groupBox2.Font = new System.Drawing.Font("Times New Roman", 14.25F);
            this.groupBox2.Location = new System.Drawing.Point(312, 98);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(398, 249);
            this.groupBox2.TabIndex = 3;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Post Preview:";
            // 
            // tb_PostPreview
            // 
            this.tb_PostPreview.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_PostPreview.Location = new System.Drawing.Point(6, 28);
            this.tb_PostPreview.Multiline = true;
            this.tb_PostPreview.Name = "tb_PostPreview";
            this.tb_PostPreview.ReadOnly = true;
            this.tb_PostPreview.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.tb_PostPreview.Size = new System.Drawing.Size(385, 215);
            this.tb_PostPreview.TabIndex = 0;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.bttn_Copy);
            this.groupBox6.Controls.Add(this.bttn_NewPost);
            this.groupBox6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox6.Location = new System.Drawing.Point(312, 353);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(259, 81);
            this.groupBox6.TabIndex = 4;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Publishing Options:";
            // 
            // bttn_Copy
            // 
            this.bttn_Copy.Location = new System.Drawing.Point(120, 28);
            this.bttn_Copy.Name = "bttn_Copy";
            this.bttn_Copy.Size = new System.Drawing.Size(126, 33);
            this.bttn_Copy.TabIndex = 2;
            this.bttn_Copy.Text = "Copy Post";
            this.bttn_Copy.Theme = "Dark";
            this.bttn_Copy.UseVisualStyleBackColor = true;
            this.bttn_Copy.Click += new System.EventHandler(this.Bttn_Copy_Click);
            // 
            // bttn_NewPost
            // 
            this.bttn_NewPost.Location = new System.Drawing.Point(10, 28);
            this.bttn_NewPost.Name = "bttn_NewPost";
            this.bttn_NewPost.Size = new System.Drawing.Size(103, 33);
            this.bttn_NewPost.TabIndex = 0;
            this.bttn_NewPost.Text = "New Post";
            this.bttn_NewPost.UseVisualStyleBackColor = true;
            this.bttn_NewPost.Click += new System.EventHandler(this.Bttn_NewPost_Click);
            // 
            // LFG_Creator_App
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(726, 576);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.lblTheme);
            this.Controls.Add(this.Combo_UITheme);
            this.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.Name = "LFG_Creator_App";
            this.Style = "Red";
            this.Text = "Anthem - LFG Post Generator";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.LFG_Creator_App_Load);
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox6.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MetroFramework.Controls.MetroComboBox Combo_UITheme;
        private System.Windows.Forms.Label lblTheme;
        private System.Windows.Forms.BindingSource bindingSource1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label1;
        private MetroFramework.Controls.MetroComboBox combo_LFM_Slots;
        public System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.GroupBox groupBox2;
        private MetroFramework.Controls.MetroTextBox tb_PostPreview;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label lblMissionType;
        private System.Windows.Forms.Label lblMissionDifficulty;
        private MetroFramework.Controls.MetroComboBox combo_MissionDiff;
        private MetroFramework.Controls.MetroComboBox combo_MissionType;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.GroupBox groupBox5;
        private MetroFramework.Controls.MetroComboBox combo_JavelinType;
        private System.Windows.Forms.Label lblJavPower;
        private System.Windows.Forms.Label lblJav;
        private MetroFramework.Controls.MetroTextBox txtBox_JavPower;
        private MetroFramework.Controls.MetroTextBox txtBox_PostDescription;
        private System.Windows.Forms.GroupBox groupBox6;
        private MetroFramework.Controls.MetroRadioButton rb_LFM;
        private MetroFramework.Controls.MetroRadioButton rb_LFG;
        private MetroFramework.Controls.MetroButton bttn_Copy;
        private MetroFramework.Controls.MetroButton bttn_NewPost;
    }
}

