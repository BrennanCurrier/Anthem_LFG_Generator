﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MetroFramework;
using System.Windows.Forms;
using System.Deployment;
using System.Diagnostics;

namespace Anthem_LFG_Creator
{
    public partial class LFG_Creator_App : MetroFramework.Forms.MetroForm
    {
        public LFG_Creator_App()
        {
            InitializeComponent();
        }

        public void NewPost()
        {
            timer1.Stop();
            Application.Restart();
        }

        public void LoadTheme(bool isUIDark, bool isUILight) {
            //Theme properties
                    Color lblColorBG = Color.Transparent;
                    int indxDarkUI = Combo_UITheme.FindString("Dark");
                    int indxLightUI = Combo_UITheme.FindString("Light");
            //Theme Dark
            string tMetroDarkUI = "Dark";
                    Color tMetroDarkUI_TextColor = Color.Orange;
                    string tMetroDarkUI_TopColor = "Orange";
                //Theme Light
                    string tMetroLightUI = "Light";
                    Color tMetroLightUI_TextColor = Color.Black;
                    string tMetroLightUI_TopColor = "Orange";
            //Set font sizes
                

            if (isUIDark == true && isUILight == false) //UIDark
            {
                this.Style = tMetroDarkUI_TopColor;

                //Set Text colors
                this.ForeColor = tMetroDarkUI_TextColor;
                lblTheme.ForeColor = tMetroDarkUI_TextColor;
                Combo_UITheme.ForeColor = tMetroDarkUI_TextColor;
                combo_LFM_Slots.ForeColor = tMetroDarkUI_TextColor;
                groupBox1.ForeColor = tMetroDarkUI_TextColor;
                groupBox2.ForeColor = tMetroDarkUI_TextColor;
                groupBox3.ForeColor = tMetroDarkUI_TextColor;
                groupBox4.ForeColor = tMetroDarkUI_TextColor;
                groupBox5.ForeColor = tMetroDarkUI_TextColor;
                groupBox6.ForeColor = tMetroDarkUI_TextColor;
                rb_LFG.ForeColor = tMetroDarkUI_TextColor;
                rb_LFM.ForeColor = tMetroDarkUI_TextColor;
                tb_PostPreview.ForeColor = tMetroDarkUI_TextColor;
                lblMissionType.ForeColor = tMetroDarkUI_TextColor;
                lblMissionDifficulty.ForeColor = tMetroDarkUI_TextColor;
                combo_MissionType.ForeColor = tMetroDarkUI_TextColor;
                combo_MissionDiff.ForeColor = tMetroDarkUI_TextColor;
                lblJav.ForeColor = tMetroDarkUI_TextColor;
                lblJavPower.ForeColor = tMetroDarkUI_TextColor;
                combo_JavelinType.ForeColor = tMetroDarkUI_TextColor;
                txtBox_JavPower.ForeColor = tMetroDarkUI_TextColor;
                txtBox_PostDescription.ForeColor = tMetroDarkUI_TextColor;
                bttn_NewPost.ForeColor = tMetroDarkUI_TextColor;
                bttn_Copy.ForeColor = tMetroDarkUI_TextColor;

            //Set Background theme
                this.Theme = tMetroDarkUI;
                lblTheme.BackColor = lblColorBG;
                Combo_UITheme.Theme = tMetroDarkUI;
                combo_LFM_Slots.Theme = tMetroDarkUI;
                Combo_UITheme.SelectedIndex = indxDarkUI;
                rb_LFG.BackColor = lblColorBG;
                rb_LFM.BackColor = lblColorBG;
                groupBox1.BackColor = lblColorBG;
                groupBox2.BackColor = lblColorBG;
                groupBox3.BackColor = lblColorBG;
                groupBox4.BackColor = lblColorBG;
                groupBox5.BackColor = lblColorBG;
                groupBox6.BackColor = lblColorBG;
                tb_PostPreview.Theme = tMetroDarkUI;
                lblMissionType.BackColor = lblColorBG;
                lblMissionDifficulty.BackColor = lblColorBG;
                combo_MissionType.Theme = tMetroDarkUI;
                combo_MissionDiff.Theme = tMetroDarkUI;
                combo_JavelinType.Theme = tMetroDarkUI;
                txtBox_JavPower.Theme = tMetroDarkUI;
                txtBox_PostDescription.Theme = tMetroDarkUI;
                lblJav.BackColor = lblColorBG;
                lblJavPower.BackColor = lblColorBG;
                bttn_Copy.Theme = tMetroDarkUI;
                bttn_NewPost.Theme = tMetroDarkUI;

            } else if (isUILight == true && isUIDark == false) //UILight
            {
                this.Style = tMetroLightUI_TopColor;

                //Set Text colors
                this.ForeColor = tMetroLightUI_TextColor;
                lblTheme.ForeColor = tMetroLightUI_TextColor;
                Combo_UITheme.ForeColor = tMetroLightUI_TextColor;
                groupBox1.ForeColor = tMetroLightUI_TextColor;
                groupBox2.ForeColor = tMetroLightUI_TextColor;
                groupBox3.ForeColor = tMetroLightUI_TextColor;
                groupBox4.ForeColor = tMetroLightUI_TextColor;
                groupBox5.ForeColor = tMetroLightUI_TextColor;
                groupBox6.ForeColor = tMetroLightUI_TextColor;
                combo_LFM_Slots.ForeColor = tMetroLightUI_TextColor;
                rb_LFM.ForeColor = tMetroLightUI_TextColor;
                rb_LFG.ForeColor = tMetroLightUI_TextColor;
                tb_PostPreview.ForeColor = tMetroLightUI_TextColor;
                lblMissionType.ForeColor = tMetroLightUI_TextColor;
                lblMissionDifficulty.ForeColor = tMetroLightUI_TextColor;
                combo_MissionType.ForeColor = tMetroLightUI_TextColor;
                combo_MissionDiff.ForeColor = tMetroLightUI_TextColor;
                lblJav.ForeColor = tMetroLightUI_TextColor;
                lblJavPower.ForeColor = tMetroLightUI_TextColor;
                combo_JavelinType.ForeColor = tMetroLightUI_TextColor;
                txtBox_JavPower.ForeColor = tMetroLightUI_TextColor;
                txtBox_PostDescription.ForeColor = tMetroLightUI_TextColor;
                bttn_Copy.ForeColor = tMetroLightUI_TextColor;
                bttn_NewPost.ForeColor = tMetroLightUI_TextColor;
                //Set Background theme
                this.Theme = tMetroLightUI;
                lblTheme.BackColor = lblColorBG;
                Combo_UITheme.Theme = tMetroLightUI;
                combo_LFM_Slots.Theme = tMetroLightUI;
                groupBox1.BackColor = lblColorBG;
                groupBox2.BackColor = lblColorBG;
                groupBox3.BackColor = lblColorBG;
                groupBox4.BackColor = lblColorBG;
                groupBox5.BackColor = lblColorBG;
                groupBox6.BackColor = lblColorBG;
                rb_LFG.BackColor = lblColorBG;
                rb_LFM.BackColor = lblColorBG; 
                Combo_UITheme.SelectedIndex = indxLightUI;
                tb_PostPreview.Theme = tMetroLightUI;
                lblMissionType.BackColor = lblColorBG;
                lblMissionDifficulty.BackColor = lblColorBG;
                combo_MissionType.Theme = tMetroLightUI;
                combo_MissionDiff.Theme = tMetroLightUI;
                combo_JavelinType.Theme = tMetroLightUI;
                txtBox_JavPower.Theme = tMetroLightUI;
                txtBox_PostDescription.Theme = tMetroLightUI;
                lblJav.BackColor = lblColorBG;
                lblJavPower.BackColor = lblColorBG;
                bttn_Copy.Theme = tMetroLightUI;
                bttn_NewPost.Theme = tMetroLightUI;
            }

        }

        public void LoadRandomTheme()
        {
            Random genNumber = new Random();
            int themeNum = genNumber.Next(0, 2);
            if (themeNum == 0) //Dark UI
            {
                LoadTheme(true, false);
            } else if (themeNum == 1) //Light UI
            {
                LoadTheme(false, true);
            }

        }

        public void NewLine(MetroFramework.Controls.MetroTextBox txtBoxCntrl)
        {
            txtBoxCntrl.AppendText(Environment.NewLine);
        }
        public void GeneratePost()
        {
            //Variables
            string postType = "";
            string lfmSlots;
            string missionType = combo_MissionType.Text;
            string missionDifficulty = combo_MissionDiff.Text;
            string javelinType = combo_JavelinType.Text;
            string javelinPower = txtBox_JavPower.Text;
            string shortDescription = txtBox_PostDescription.Text;
            

            //If conditions
            if (rb_LFG.Checked == true)//LFG selected
            {
                postType = "LFG";
            }
            else if(rb_LFM.Checked == true)//LFM Selected
            {
                postType = "LFM";
            }

            //Generation Code
            tb_PostPreview.Clear();
            tb_PostPreview.AppendText("Group Type: " + postType);
            if (rb_LFM.Checked == true) //LFM Generator
            {
                lfmSlots = combo_LFM_Slots.Text;
                NewLine(tb_PostPreview);
                tb_PostPreview.AppendText("Slots: " + lfmSlots);
            }
            NewLine(tb_PostPreview);
            tb_PostPreview.AppendText("Group Type: " + missionType);
            NewLine(tb_PostPreview);
            tb_PostPreview.AppendText("Difficulty: " + missionDifficulty);
            NewLine(tb_PostPreview);
            tb_PostPreview.AppendText("Javelin: " + javelinType);
            tb_PostPreview.AppendText(" (" + javelinPower + " Power)");
            NewLine(tb_PostPreview);
            tb_PostPreview.AppendText("Short Description: ");
            NewLine(tb_PostPreview);
            tb_PostPreview.AppendText(shortDescription);
        }
        private void LFG_Creator_App_Load(object sender, EventArgs e)
        {
            //Load Random theme on start
            LoadRandomTheme();
            timer1.Start();
        }

        private void Combo_UITheme_SelectedIndexChanged(object sender, EventArgs e)
        {
            int indxDarkUI = Combo_UITheme.FindString("Dark");
            int indxLightUI = Combo_UITheme.FindString("Light");
            if (Combo_UITheme.SelectedIndex == indxDarkUI)
            {
                LoadTheme(true, false);
            }
            else if (Combo_UITheme.SelectedIndex == indxLightUI)
            {
                LoadTheme(false, true);
            }
        }

        private void Timer1_Tick(object sender, EventArgs e)
        {
            if (rb_LFM.Checked == true)
            {
                combo_LFM_Slots.Enabled = true;
            } else if(rb_LFM.Checked == false) {
                combo_LFM_Slots.Enabled = false;
            }

            GeneratePost();
        }

        private void Bttn_NewPost_Click(object sender, EventArgs e)
        {
            NewPost();
        }

        private void Bttn_Copy_Click(object sender, EventArgs e)
        {
            Clipboard.SetText(tb_PostPreview.Text);
            MessageBox.Show(null, "Copied to clipboard, now just paste into the discord", "Copied!");
        }
    }
}
